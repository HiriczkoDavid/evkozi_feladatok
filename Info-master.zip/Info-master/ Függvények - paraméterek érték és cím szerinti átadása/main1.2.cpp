#include <iostream>
using namespace std;

int lnko(int a, int b) {
    while (a!=b) {
        if (a>b) {
            a=a-b;
        }
        else {
            b=b-a;
        }
    }
    return a1;
  }
   int lkkt () {
    return a*b/lnko(a,b) ;
   }
using namespace std;

int main()
{
     a=2;
     b=3;
    cout << lnko () << endl;
    cout << lkkt () << endl;



    return 0;
}
