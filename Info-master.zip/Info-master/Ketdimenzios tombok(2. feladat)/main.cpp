#include <iostream>
#include <stdlib.h>

using namespace std;

int main()
{

  int N,M,i,j;
  cout << "N=";
  cin >> N;
  int v[N];
  int matrix [N][M] ;
  for (i=0; i<N; i++) {
    v[i]=rand()%100;
  }


















    return 0;
}
