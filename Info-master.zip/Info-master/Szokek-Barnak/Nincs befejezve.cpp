#include <iostream>

using namespace std;
struct diak {
   string nev;
   string hajszin;
   float matj;
} xi.b[32];

int main()
{
    int n,a,b;
    cout << "Hany szemely van az osztalyba?" << endl;
    cin >> n;
    for (i=0; i<n; i++) {
        cout << "Diak neve" ;
        cin >> XI.B[i].nev;
        cout  <<  XI.B[i].nev << "hajszin" ;
        cin >> XI.B[i].hajszin;
        cout <<  XI.B[i].nev << "mat jegy" ;
        cin >>  XI.B[i].matj;
    }
    int szoke=0, barna=0;
    float Sszoke, Sbarna;
    Sszoke=0, Sbarna=0;
    return 0;
}
