#include <iostream>

using namespace std;

int main()
{
   int V[100],i,n;
   cout << "n=";
   cin >> n;
   for (i=0; i<=n; i++) {

   }






    return 0;
}
