#include <iostream>

using namespace std;
int csap [2][N+1];
for (int i=1; N+1; i++) {
    csap[0][i] =hany_db(v,1,N) ;
    csap [1][i]=i;
}
 for (int i=1; i<N; i++) {
    for (int j=i+1; j<N+1; j++) {
        if (csp[0][i]> csp[0][j]) {

        }
    }
 }

int main()
{
    cout << "Hello world!" << endl;
    return 0;
}
