#include <iostream>
#include <string>

using namespace std;

int main()
{
  string a;
  string b("Ez egy string") ;
  cout << "a=" ;
  cin >>a;
  cout << a << " " << a.length() << endl;
  cout << b << " " << b.size() << endl;






    return 0;
}
